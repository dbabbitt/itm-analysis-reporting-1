import fs from 'fs';
import path from 'path';
import { Map } from 'immutable';
import { parse } from 'csv-parse';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
import { DataFrame } from 'dataframe-js';
import { promisify } from 'util';
import {analyzeDataInline, analyzeData} from './library.js'

const readdir_promise = promisify(fs.readdir);
const createWriteStream_promise = promisify(fs.createWriteStream);

const __dirname = dirname(fileURLToPath(import.meta.url));


const COL_DEFS = {
    BAG_ACCESS : ["Type", "Tick", "Timestamp", "ID", "Location"],
    BAG_CLOSED : ["Type", "Tick", "Timestamp", "ID", "Location"],
    GENERIC_METRIC_EVENT : ["Type", "Tick", "Timestamp", "ID", "Message", "Label"],
    INJURY_RECORD : ["Type", "Tick", "Timestamp", "ID", "InjuryID", "PatientID", "RequiredProcedure", "Severity", "BodyRegion", "InjuryTreated", "injuryTreatedWithWrongTreatment", "InjuryLocator"],
    INJURY_TREATED : ["Type", "Tick", "Timestamp", "ID", "InjuryID", "PatientID", "RequiredProcedure", "Severity", "BodyRegion", "InjuryTreated", "injuryTreatedWithWrongTreatment", "InjuryLocator"],
    PATIENT_DEMOTED : ["Type", "Tick", "Timestamp", "ID", "HealthLevel", "HealthRemaining", "PatientID", "Position", "Rotation", "SALT", "Sort", "Pulse", "Breath", "Hearing", "Mood", "Pose"],
    PATIENT_ENGAGED : ["Type", "Tick", "Timestamp", "ID", "HealthLevel", "HealthRemaining", "PatientID", "Position", "Rotation", "SALT", "Sort", "Pulse", "Breath", "Hearing", "Mood", "Pose"],
    PATIENT_RECORD : ["Type", "Tick", "Timestamp", "ID", "HealthLevel", "HealthRemaining", "PatientID", "Position", "Rotation", "SALT", "Sort", "Pulse", "Breath", "Hearing", "Mood", "Pose"],
    PULSE_TAKEN : ["Type", "Tick", "Timestamp", "ID", "PulseName", "PatientID"],
    S_A_L_T_SORT : ["Type", "Tick", "Timestamp", "ID", "SortLocation", "SortCommandText", "PatientID"],
    S_A_L_T_WALKED : ["Type", "Tick", "Timestamp", "ID", "SortLocation", "SortCommandText", "PatientID"],
    S_A_L_T_WALK_IF_CAN : ["Type", "Tick", "Timestamp", "ID", "SortLocation", "SortCommandText", "PatientID"],
    S_A_L_T_WAVED : ["Type", "Tick", "Timestamp", "ID", "SortLocation", "SortCommandText", "PatientID"],
    S_A_L_T_WAVE_IF_CAN : ["Type", "Tick", "Timestamp", "ID", "SortLocation", "SortCommandText", "PatientID"],
    SESSION_END : ["Type", "Tick", "Timestamp", "ID"],
    SESSION_START : ["Type", "Tick", "Timestamp", "ID"],
    TAG_APPLIED : ["Type", "Tick", "Timestamp", "ID", "PatientID", "TagType", "TagDiscarded", "TagDiscardedType", "Location"],
    TAG_DISCARDED : ["Type", "Tick", "Timestamp", "ID", "TagType", "Location"],
    TAG_SELECTED : ["Type", "Tick", "Timestamp", "ID", "TagType"],
    TELEPORT : ["Type", "Tick", "Timestamp", "ID", "Location"],
    TOOL_APPLIED : ["Type", "Tick", "Timestamp", "ID", "PatientID", "ToolType", "AttachmentPoint", "ToolLocation", "Data", "Sender", "AttachMessage"],
    TOOL_DISCARDED : ["Type", "Tick", "Timestamp", "ID", "ToolType", "ToolCount"],
    TOOL_HOVER : ["Type", "Tick", "Timestamp", "ID", "ToolType", "ToolCount"],
    TOOL_SELECTED : ["Type", "Tick", "Timestamp", "ID", "ToolType", "ToolCount"],
    VOICE_CAPTURE : ["Type", "Tick", "Timestamp", "ID", "Message", "CommandDescription"],
    VOICE_COMMAND : ["Type", "Tick", "Timestamp", "ID", "Message", "CommandDescription"]
};

function readDataDirectory(dir) {
    return readdir_promise(dir, { encoding: 'utf8' })
        .then(filenames => {
            const files = getFiles(dir, filenames);

            return Promise.all(files);
        })
        .catch(err => console.error(err));
}

function getFiles(dir, filenames) {
    return filenames.map(filename => {
        const name = path.parse(filename).name;
        const ext = path.parse(filename).ext;
        const filepath = path.resolve(dir, filename);
        return readCSV(filepath, name);
    });
}


function readCSV(filepath, filename) {

    const p = new Promise((resolve, reject) => {
        let _data = [];
        let DATA_CATEGORIES = {};
        let DATA_FRAMES = {};
        let DATA_ENTRIES = {};

        function processCSVImport (data) {
            for (let i = 0; i < data.length; i++) {
                if (!DATA_CATEGORIES[data[i][0]]) {
                    DATA_CATEGORIES[data[i][0]] = [];
                }
                DATA_CATEGORIES[data[i][0]].push (data[i].slice(0, COL_DEFS[data[i][0]].length));
            }

            for (const dk in DATA_CATEGORIES) {
                if (DATA_CATEGORIES[dk].length > 0) {
                    if (!DATA_ENTRIES[dk]) DATA_ENTRIES[dk] = [];

                    for (let i = 0; i < DATA_CATEGORIES[dk].length; i++) {
                        DATA_ENTRIES[dk].push (newDataEntry (COL_DEFS[dk], DATA_CATEGORIES[dk][i]));
                    }

                }
            }

            for (const dk in DATA_CATEGORIES) {
                DATA_FRAMES[dk] = new DataFrame(DATA_ENTRIES[dk]);
            }
        }

        let output = "";
        function log (str) {
            output += str + "\r";
        }

        console.log ("Ingesting data...");


        fs.createReadStream(filepath)
            .pipe(parse({ delimiter: ',', from_line: 2, relax_quotes: true, relax_column_count:true }))
            .on('data', function (row) {
                _data.push(row);
            })
            .on('end', function () {
                processCSVImport(_data);
                console.log ("Ingesting data done! " + filepath);

                analyzeData(_data, log, DATA_FRAMES);
                writeLog(__dirname + (!outDir.startsWith(path.sep)?path.sep:"")  + outDir + (!outDir.endsWith(path.sep)?path.sep:"") + filename + "_out.csv", output);
                output = "";
                analyzeDataInline(_data, log, DATA_FRAMES);
                writeLog(__dirname + (!outDir.startsWith(path.sep)?path.sep:"")  + outDir + (!outDir.endsWith(path.sep)?path.sep:"") + filename + "_out_inline.csv", output);
                output = "";

                resolve();
            });
    })

    return p;
}

function newDataEntry (keys, values) {
    let o = {};
    for (let i = 0; i < keys.length; i++) {
        o[keys[i]] = values[i];
    }
    return o;
}


function writeLog (path, output) {
    let writeStream = fs.createWriteStream(path);
    writeStream.write(output);
    writeStream.end();
}

let inDir = "/data";
let outDir = "/out";

if (process.argv.length === 4) {
    inDir = process.argv[2];
    outDir = process.argv[3];

    readDataDirectory (__dirname + (!inDir.startsWith(path.sep)?path.sep:"")  + inDir + (!inDir.endsWith(path.sep)?path.sep:"")).then(files => {console.log ("Processing complete.")});
}
else {
    console.log ("usage: p.js [in_dir] [out_dir]");
}