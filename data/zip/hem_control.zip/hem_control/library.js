import {DataFrame} from "dataframe-js";

export const analyzeData = (_data, log, DATA_FRAMES) => {
    let SESSIONS = [];
    if (_data.length > 0) {
        if ((DATA_FRAMES["SESSION_START"] != null) && (DATA_FRAMES["SESSION_END"] != null)) {
            for (let i = 0; i < DATA_FRAMES["SESSION_START"].count(); i++) {
                SESSIONS.push({
                    start: parseInt(DATA_FRAMES["SESSION_START"].getRow(i).get("Tick")),
                    end: parseInt(DATA_FRAMES["SESSION_END"].getRow(i).get("Tick")),
                    id: DATA_FRAMES["SESSION_END"].getRow(i).get("ID"),
                    timestamp: DATA_FRAMES["SESSION_END"].getRow(i).get("Timestamp")
                });
            }
            console.log("Found " + SESSIONS.length + " session" + (SESSIONS.length > 1 ? "s" : "") + " in data file.");
            for (const sk in SESSIONS) {

                let patients = DATA_FRAMES["PATIENT_RECORD"].chain(
                    row => {
                        return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                    },
                    row => {
                        return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                    }
                );

                let walk;
                let wave;

                if (DATA_FRAMES["S_A_L_T_WALK_IF_CAN"]) {
                    walk = DATA_FRAMES["S_A_L_T_WALK_IF_CAN"].chain(
                        row => {
                            return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                        },
                        row => {
                            return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                        }
                    );
                }

                if (DATA_FRAMES["S_A_L_T_WAVE"]) {
                    wave = DATA_FRAMES["S_A_L_T_WAVE"].chain(
                        row => {
                            return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                        },
                        row => {
                            return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                        }
                    );
                }

                let sessionDf = new DataFrame([[
                        SESSIONS[sk].id,
                        (walk != null && walk.count() > 0),
                        (wave != null && wave.count() > 0),
                        SESSIONS[sk].timestamp
                    ]],
                    ['id', 'walk', 'wave', 'timestamp']
                );

                log(sessionDf.toCSV(false));

                for (let n = 0; n < patients.count(); n++) {
                    let patient = patients.getRow(n);
                    let injuries;
                    let injuriesTreated;
                    let pulses;
                    let tags;

                    if (DATA_FRAMES["INJURY_RECORD"]) {
                        injuries = DATA_FRAMES["INJURY_RECORD"].chain(
                            row => {
                                return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                            },
                            row => {
                                return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                            },
                            row => row.get('PatientID') === patient.get('PatientID')
                        );
                    }

                    if (DATA_FRAMES["TAG_APPLIED"]) {
                        tags = DATA_FRAMES["TAG_APPLIED"].chain(
                            row => {
                                return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                            },
                            row => {
                                return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                            },
                            row => row.get('PatientID') === patient.get('PatientID')
                        );
                    }

                    if (DATA_FRAMES["INJURY_TREATED"]) {
                        injuriesTreated = DATA_FRAMES["INJURY_TREATED"].chain(
                            row => {
                                return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                            },
                            row => {
                                return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                            },
                            row => {
                                return row.get('PatientID') == patient.get('PatientID');
                            }
                        );
                    }

                    if (DATA_FRAMES["PULSE_TAKEN"]) {
                        pulses = DATA_FRAMES["PULSE_TAKEN"].chain(
                            row => {
                                return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                            },
                            row => {
                                return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                            },
                            row => row.get('PatientID') == patient.get('PatientID')
                        );
                    }

                    let patientDf = new DataFrame([[
                            patient.get('PatientID'),
                            patient.get('SALT'),
                            ((tags != null && tags.count() > 0) ? parseInt(tags.tail(1).getRow(0).get("Tick")) - SESSIONS[sk].start : -1),
                            ((tags != null && tags.count() > 0) ? tags.tail(1).getRow(0).get("TagType") : -1),
                            (pulses != null && pulses.count() > 0)
                        ]],
                        ['id', 'status', 'tagtime', 'tagtype', "pulsetaken"]
                    );

                    log(patientDf.toCSV(false));

                    let injuryList = [];
                    if (injuries != null && injuries.count() > 0) {
                        for (let i = 0; i < injuries.count(); i++) {
                            let inj = injuries.getRow(i);
                            let injTr;
                            if (injuriesTreated != null && injuriesTreated.count() > 0) {
                                injTr = injuriesTreated.chain(
                                    row => row.get('PatientID') == inj.get('PatientID'),
                                    row => row.get('InjuryID') == inj.get('InjuryID')
                                );
                            }

                            injuryList.push([
                                inj.get("InjuryID"),
                                inj.get("RequiredProcedure"),
                                (injTr != null && injTr.count() > 0),
                                ((injTr != null && injTr.count() > 0) ? parseInt(injTr.tail(1).getRow(0).get("Tick")) - SESSIONS[sk].start : -1)
                            ]);
                        }
                    }

                    let injuryDf = new DataFrame(injuryList,
                        ['id', 'treatment', 'treated', 'time']
                    );
                    log(injuryDf.toCSV(false));


                }
            }
        } else {
            console.log("file contains no valid sessions.");
        }
    } else {
        console.log("file is empty.");
    }
}

export const analyzeDataInline = (_data, log, DATA_FRAMES) => {
    let SESSIONS = [];
    if (_data.length > 0) {
        if ((DATA_FRAMES["SESSION_START"] != null) && (DATA_FRAMES["SESSION_END"] != null)) {
            for (let i = 0; i < DATA_FRAMES["SESSION_START"].count(); i++) {
                SESSIONS.push({
                    start: parseInt(DATA_FRAMES["SESSION_START"].getRow(i).get("Tick")),
                    end: parseInt(DATA_FRAMES["SESSION_END"].getRow(i).get("Tick")),
                    id: DATA_FRAMES["SESSION_END"].getRow(i).get("ID"),
                    timestamp: DATA_FRAMES["SESSION_END"].getRow(i).get("Timestamp")
                });
            }
            console.log("Found " + SESSIONS.length + " session" + (SESSIONS.length > 1 ? "s" : "") + " in data file.");
            for (const sk in SESSIONS) {

                let patients = DATA_FRAMES["PATIENT_RECORD"].chain(
                    row => {
                        return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                    },
                    row => {
                        return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                    }
                );

                let walk;
                let wave;

                if (DATA_FRAMES["S_A_L_T_WALK_IF_CAN"]) {
                    walk = DATA_FRAMES["S_A_L_T_WALK_IF_CAN"].chain(
                        row => {
                            return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                        },
                        row => {
                            return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                        }
                    );
                }

                if (DATA_FRAMES["S_A_L_T_WAVE"]) {
                    wave = DATA_FRAMES["S_A_L_T_WAVE"].chain(
                        row => {
                            return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                        },
                        row => {
                            return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                        }
                    );
                }

                let dataOutput = [];
                dataOutput.push(
                    SESSIONS[sk].id,
                    (walk != null && walk.count() > 0),
                    (wave != null && wave.count() > 0),
                    SESSIONS[sk].timestamp
                );
                // let sessionDf = new DataFrame([[
                //         SESSIONS[sk].id,
                //         (walk != null && walk.count() > 0),
                //         (wave != null && wave.count() > 0),
                //         SESSIONS[sk].timestamp
                //     ]]
                // );

                //log(sessionDf.toCSV(false));

                for (let n = 0; n < patients.count(); n++) {
                    let patient = patients.getRow(n);
                    let injuries;
                    let injuriesTreated;
                    let pulses;
                    let tags;

                    if (DATA_FRAMES["INJURY_RECORD"]) {
                        injuries = DATA_FRAMES["INJURY_RECORD"].chain(
                            row => {
                                return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                            },
                            row => {
                                return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                            },
                            row => row.get('PatientID') === patient.get('PatientID')
                        );
                    }

                    if (DATA_FRAMES["TAG_APPLIED"]) {
                        tags = DATA_FRAMES["TAG_APPLIED"].chain(
                            row => {
                                return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                            },
                            row => {
                                return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                            },
                            row => row.get('PatientID') === patient.get('PatientID')
                        );
                    }

                    if (DATA_FRAMES["INJURY_TREATED"]) {
                        injuriesTreated = DATA_FRAMES["INJURY_TREATED"].chain(
                            row => {
                                return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                            },
                            row => {
                                return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                            },
                            row => {
                                return row.get('PatientID') == patient.get('PatientID');
                            }
                        );
                    }

                    if (DATA_FRAMES["PULSE_TAKEN"]) {
                        pulses = DATA_FRAMES["PULSE_TAKEN"].chain(
                            row => {
                                return parseInt(row.get('Tick')) >= SESSIONS[sk].start;
                            },
                            row => {
                                return parseInt(row.get('Tick')) <= SESSIONS[sk].end;
                            },
                            row => row.get('PatientID') == patient.get('PatientID')
                        );
                    }

                    // sessionDf.push ([
                    //         patient.get('PatientID'),
                    //         patient.get('SALT'),
                    //         ((tags != null && tags.count() > 0) ? parseInt(tags.tail(1).getRow(0).get("Tick")) - SESSIONS[sk].start : -1),
                    //         ((tags != null && tags.count() > 0) ? tags.tail(1).getRow(0).get("TagType") : -1),
                    //         (pulses != null && pulses.count() > 0)
                    //     ]
                    // );

                    dataOutput.push(
                        patient.get('PatientID'),
                        patient.get('SALT'),
                        ((tags != null && tags.count() > 0) ? parseInt(tags.tail(1).getRow(0).get("Tick")) - SESSIONS[sk].start : -1),
                        ((tags != null && tags.count() > 0) ? tags.tail(1).getRow(0).get("TagType") : -1),
                        (pulses != null && pulses.count() > 0)
                    );

                    //log(patientDf.toCSV(false));

                    let injuryList = [];
                    if (injuries != null && injuries.count() > 0) {
                        for (let i = 0; i < injuries.count(); i++) {
                            let inj = injuries.getRow(i);
                            let injTr;
                            if (injuriesTreated != null && injuriesTreated.count() > 0) {
                                injTr = injuriesTreated.chain(
                                    row => row.get('PatientID') == inj.get('PatientID'),
                                    row => row.get('InjuryID') == inj.get('InjuryID')
                                );
                            }

                            dataOutput.push(
                                inj.get("InjuryID"),
                                inj.get("RequiredProcedure"),
                                (injTr != null && injTr.count() > 0),
                                ((injTr != null && injTr.count() > 0) ? parseInt(injTr.tail(1).getRow(0).get("Tick")) - SESSIONS[sk].start : -1)
                            );
                        }
                    }
                }
                let dataOutDF = new DataFrame([dataOutput]);
                log(dataOutDF.toCSV(false));
            }
        } else {
            console.log("file contains no valid sessions.");
        }
    } else {
        console.log("file is empty.");
    }
}
